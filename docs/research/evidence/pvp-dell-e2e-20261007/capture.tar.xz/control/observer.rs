//! Read-only character-device user observation; not GPU admission.
mod device_users;
use std::path::Path;
fn main() -> std::process::ExitCode {
    let mut args: Vec<String> = std::env::args().skip(1).collect();
    let detailed = args.first().is_some_and(|a| a == "--details");
    if detailed {
        args.remove(0);
    }
    if args.is_empty() || args.iter().any(|a| !Path::new(a).is_absolute()) {
        eprintln!("usage: remoteops-device-users [--details] /dev/DEVICE [/dev/DEVICE ...]");
        return std::process::ExitCode::from(1);
    }
    let paths: Vec<_> = args.iter().map(Path::new).collect();
    let result = if detailed {
        device_users::observe_device_users_with_details(&paths)
            .map(|d| (d.to_json(), d.observation.partial()))
    } else {
        device_users::observe_device_users(&paths)
            .map(|o| (o.to_json(), o.partial()))
    };
    match result {
        Ok((json, partial)) => {
            println!("{json}");
            std::process::ExitCode::from(if partial { 2 } else { 0 })
        }
        Err(error) => {
            eprintln!("device-user observation unavailable: {error}");
            std::process::ExitCode::from(1)
        }
    }
}
fn json_escape(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    for character in value.chars() {
        match character {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c.is_control() => {
                use std::fmt::Write as _;
                let _ = write!(out, "\\u{:04x}", c as u32);
            }
            c => out.push(c),
        }
    }
    out
}
