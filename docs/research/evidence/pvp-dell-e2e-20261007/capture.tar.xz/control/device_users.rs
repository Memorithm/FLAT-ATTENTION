//! Read-only Linux character-device users, without vendor APIs or subprocesses.
//!
//! A visible /proc descriptor scan is an observation, never GPU-idle evidence
//! or exclusive-device admission. Inaccessible entries remain explicit.

use std::io;
use std::path::Path;

/// Device identity observed through filesystem metadata.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeviceIdentity {
    pub path: String,
    pub raw_device: u64,
}

/// One visible process holding at least one descriptor to a requested device.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct DeviceUser {
    pub pid: u32,
    pub device_index: usize,
}

/// Diagnostic data only; no capacity or exclusivity capability is granted.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeviceUsersObservation {
    pub devices: Vec<DeviceIdentity>,
    pub users: Vec<DeviceUser>,
    pub processes_scanned: usize,
    pub descriptors_inspected: usize,
    pub unreadable_entries: usize,
    pub scan_limit_reached: bool,
}

impl DeviceUsersObservation {
    #[must_use]
    pub fn partial(&self) -> bool {
        self.unreadable_entries != 0 || self.scan_limit_reached
    }

    #[must_use]
    pub fn to_json(&self) -> String {
        let devices = self
            .devices
            .iter()
            .map(|d| {
                format!(
                    "{{\"path\":\"{}\",\"raw_device\":{}}}",
                    crate::json_escape(&d.path),
                    d.raw_device
                )
            })
            .collect::<Vec<_>>()
            .join(",");
        let users = self
            .users
            .iter()
            .map(|u| format!("{{\"pid\":{},\"device_index\":{}}}", u.pid, u.device_index))
            .collect::<Vec<_>>()
            .join(",");
        format!(
            concat!(
                "{{\"schema\":\"remoteops.device-users/v1\",",
                "\"scope\":\"visible_proc_namespace\",",
                "\"status\":\"{}\",\"devices\":[{}],\"users\":[{}],",
                "\"processes_scanned\":{},\"descriptors_inspected\":{},",
                "\"unreadable_entries\":{},\"scan_limit_reached\":{},",
                "\"demonstrates_device_idle\":false,\"qualifies_exclusivity\":false}}"
            ),
            if self.partial() {
                "partial"
            } else {
                "observed"
            },
            devices,
            users,
            self.processes_scanned,
            self.descriptors_inspected,
            self.unreadable_entries,
            self.scan_limit_reached
        )
    }
}

/// One enumeration gap, with bounded diagnostic process identity.
/// Identity is verified only when start ticks and cgroup agree before/after.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeviceObservationGap {
    pub pid: Option<u32>,
    pub stage: &'static str,
    pub count: usize,
    pub cgroup_v2: Option<String>,
    pub process_identity_verified: bool,
}

/// Opt-in v2 detail; partial state and both capability denials are preserved.
type GapKey = (Option<u32>, &'static str, Option<String>, bool);

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeviceUsersDetails {
    pub observation: DeviceUsersObservation,
    pub gaps: Vec<DeviceObservationGap>,
    pub gap_details_truncated: bool,
    collect_details: bool,
    gap_index: std::collections::BTreeMap<GapKey, usize>,
}
impl DeviceUsersDetails {
    #[must_use]
    pub fn to_json(&self) -> String {
        let mut base = self.observation.to_json().replacen(
            "remoteops.device-users/v1",
            "remoteops.device-users/v2",
            1,
        );
        base.pop();
        let gaps = self.gaps.iter().map(|g| {
            let pid = g.pid.map_or_else(|| "null".to_owned(), |p| p.to_string());
            let cgroup = g.cgroup_v2.as_ref().map_or_else(|| "null".to_owned(),
                |c| format!("\"{}\"", crate::json_escape(c)));
            format!("{{\"pid\":{pid},\"stage\":\"{}\",\"count\":{},\"cgroup_v2\":{cgroup},\"process_identity_verified\":{}}}",
                g.stage, g.count, g.process_identity_verified)
        }).collect::<Vec<_>>().join(",");
        format!(
            "{base},\"gaps\":[{gaps}],\"gap_details_truncated\":{}}}",
            self.gap_details_truncated
        )
    }
    fn gap(
        &mut self,
        pid: Option<u32>,
        stage: &'static str,
        before: Option<&(String, String)>,
        after: Option<(String, String)>,
    ) {
        self.observation.unreadable_entries += 1;
        if !self.collect_details {
            return;
        }
        let verified = before.is_some() && before == after.as_ref();
        let cgroup = if verified { after.map(|i| i.1) } else { None };
        let key = (pid, stage, cgroup.clone(), verified);
        if let Some(&index) = self.gap_index.get(&key) {
            self.gaps[index].count += 1;
        } else if self.gaps.len() < 4096 {
            self.gap_index.insert(key, self.gaps.len());
            self.gaps.push(DeviceObservationGap {
                pid,
                stage,
                count: 1,
                cgroup_v2: cgroup,
                process_identity_verified: verified,
            });
        } else {
            self.gap_details_truncated = true;
        }
    }
}

/// Opt-in Linux process-gap attribution; never an admission decision.
pub fn observe_device_users_with_details(paths: &[&Path]) -> io::Result<DeviceUsersDetails> {
    #[cfg(target_os = "linux")]
    {
        observe_detailed_at(Path::new("/proc"), paths, ScanLimits::default(), true)
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = paths;
        Err(io::Error::new(
            io::ErrorKind::Unsupported,
            "Linux /proc required",
        ))
    }
}

#[cfg(target_os = "linux")]
fn process_identity(path: &Path) -> Option<(String, String)> {
    use std::io::Read;
    fn bounded(path: &Path) -> Option<String> {
        let file = std::fs::File::open(path).ok()?;
        let mut text = String::new();
        file.take(4097).read_to_string(&mut text).ok()?;
        if text.len() > 4096 {
            None
        } else {
            Some(text)
        }
    }
    let stat = bounded(&path.join("stat"))?;
    let (_, fields) = stat.rsplit_once(") ")?;
    let start = fields.split_whitespace().nth(19)?.to_owned();
    start.parse::<u64>().ok()?;
    let cgroups = bounded(&path.join("cgroup"))?;
    let cgroup = cgroups
        .lines()
        .find_map(|l| l.strip_prefix("0::"))?
        .to_owned();
    if !cgroup.starts_with('/') {
        return None;
    }
    Some((start, cgroup))
}

/// Inspect the currently visible Linux /proc namespace for requested devices.
/// Paths must name character devices; aliases with the same rdev are rejected.
/// No device is opened, no process is stopped and no command is executed.
pub fn observe_device_users(paths: &[&Path]) -> io::Result<DeviceUsersObservation> {
    #[cfg(target_os = "linux")]
    {
        observe_at(Path::new("/proc"), paths, ScanLimits::default())
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = paths;
        Err(io::Error::new(
            io::ErrorKind::Unsupported,
            "Linux /proc required",
        ))
    }
}

#[cfg(target_os = "linux")]
#[derive(Clone, Copy)]
struct ScanLimits {
    processes: usize,
    descriptors: usize,
    users: usize,
}

#[cfg(target_os = "linux")]
impl Default for ScanLimits {
    fn default() -> Self {
        Self {
            processes: 100_000,
            descriptors: 1_000_000,
            users: 4096,
        }
    }
}

#[cfg(target_os = "linux")]
fn observe_at(
    proc_root: &Path,
    paths: &[&Path],
    limits: ScanLimits,
) -> io::Result<DeviceUsersObservation> {
    Ok(observe_detailed_at(proc_root, paths, limits, false)?.observation)
}

#[cfg(target_os = "linux")]
fn observe_detailed_at(
    proc_root: &Path,
    paths: &[&Path],
    limits: ScanLimits,
    detailed: bool,
) -> io::Result<DeviceUsersDetails> {
    use std::collections::BTreeSet;
    use std::fs;
    use std::os::unix::fs::{FileTypeExt, MetadataExt};
    if paths.is_empty() || paths.len() > 32 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "require 1..32 devices",
        ));
    }
    let mut devices = Vec::new();
    for path in paths {
        let metadata = fs::metadata(path)?;
        if !metadata.file_type().is_char_device()
            || devices
                .iter()
                .any(|d: &DeviceIdentity| d.raw_device == metadata.rdev())
        {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "non-character device or duplicate identity",
            ));
        }
        let path = path
            .to_str()
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "non-UTF8 device path"))?;
        devices.push(DeviceIdentity {
            path: path.to_owned(),
            raw_device: metadata.rdev(),
        });
    }
    let observation = DeviceUsersObservation {
        devices,
        users: Vec::new(),
        processes_scanned: 0,
        descriptors_inspected: 0,
        unreadable_entries: 0,
        scan_limit_reached: false,
    };
    let mut details = DeviceUsersDetails {
        observation,
        gaps: Vec::new(),
        gap_details_truncated: false,
        collect_details: detailed,
        gap_index: std::collections::BTreeMap::new(),
    };
    let mut users = BTreeSet::new();
    'scan: for entry in fs::read_dir(proc_root)? {
        let entry = match entry {
            Ok(e) => e,
            Err(_) => {
                details.gap(None, "proc_entry", None, None);
                continue;
            }
        };
        let name = entry.file_name();
        let Some(name) = name.to_str() else {
            continue;
        };
        if name.is_empty() || !name.bytes().all(|b| b.is_ascii_digit()) {
            continue;
        }
        let Ok(pid) = name.parse::<u32>() else {
            details.gap(None, "pid_parse", None, None);
            continue;
        };
        if pid == 0 {
            continue;
        }
        if details.observation.processes_scanned >= limits.processes {
            details.observation.scan_limit_reached = true;
            break;
        }
        details.observation.processes_scanned += 1;
        let before = if detailed {
            process_identity(&entry.path())
        } else {
            None
        };
        let fds = match fs::read_dir(entry.path().join("fd")) {
            Ok(fds) => fds,
            Err(_) => {
                details.gap(
                    Some(pid),
                    "fd_directory",
                    before.as_ref(),
                    if detailed {
                        process_identity(&entry.path())
                    } else {
                        None
                    },
                );
                continue;
            }
        };
        for fd in fds {
            if details.observation.descriptors_inspected >= limits.descriptors {
                details.observation.scan_limit_reached = true;
                break 'scan;
            }
            details.observation.descriptors_inspected += 1;
            let metadata = match fd.and_then(|fd| fs::metadata(fd.path())) {
                Ok(m) => m,
                Err(_) => {
                    details.gap(
                        Some(pid),
                        "fd_metadata",
                        before.as_ref(),
                        if detailed {
                            process_identity(&entry.path())
                        } else {
                            None
                        },
                    );
                    continue;
                }
            };
            if !metadata.file_type().is_char_device() {
                continue;
            }
            for (device_index, device) in details.observation.devices.iter().enumerate() {
                if device.raw_device == metadata.rdev() {
                    let user = DeviceUser { pid, device_index };
                    if !users.contains(&user) && users.len() >= limits.users {
                        details.observation.scan_limit_reached = true;
                        break 'scan;
                    }
                    users.insert(user);
                }
            }
        }
    }
    details.observation.users = users.into_iter().collect();
    Ok(details)
}

#[cfg(all(test, target_os = "linux"))]
mod tests {
    use super::*;
    use std::fs;
    use std::os::unix::fs::symlink;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};

    struct Fixture(PathBuf);
    impl Fixture {
        fn new() -> Self {
            static NEXT: AtomicU64 = AtomicU64::new(0);
            let root = std::env::temp_dir().join(format!(
                "remoteops-device-users-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            fs::create_dir(&root).unwrap();
            Self(root)
        }
        fn fd(&self, pid: u32, fd: u32, target: &str) {
            let dir = self.0.join(pid.to_string()).join("fd");
            fs::create_dir_all(&dir).unwrap();
            symlink(target, dir.join(fd.to_string())).unwrap();
        }
        fn observe(&self) -> DeviceUsersObservation {
            observe_at(
                &self.0,
                &[Path::new("/dev/null"), Path::new("/dev/zero")],
                ScanLimits::default(),
            )
            .unwrap()
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    #[test]
    fn device_identity_deduplicates_fds_and_sorts_users() {
        let f = Fixture::new();
        f.fd(42, 1, "/dev/null");
        f.fd(42, 2, "/dev/null");
        f.fd(7, 3, "/dev/zero");
        f.fd(7, 4, "/dev/null");
        f.fd(9, 1, "/dev/urandom");
        let o = f.observe();
        assert_eq!(
            o.users,
            vec![
                DeviceUser {
                    pid: 7,
                    device_index: 0
                },
                DeviceUser {
                    pid: 7,
                    device_index: 1
                },
                DeviceUser {
                    pid: 42,
                    device_index: 0
                }
            ]
        );
        assert_eq!(o.processes_scanned, 3);
        assert_eq!(o.descriptors_inspected, 5);
        assert!(!o.partial());
    }
    #[test]
    fn incomplete_or_disappeared_entries_never_become_complete_observation() {
        let f = Fixture::new();
        f.fd(7, 1, "/remoteops-nonexistent-device-test");
        fs::create_dir(f.0.join("42")).unwrap();
        let o = f.observe();
        assert!(o.partial());
        assert_eq!(o.unreadable_entries, 2);
        assert!(o.to_json().contains("\"status\":\"partial\""));
    }
    #[test]
    fn limits_preserve_unknown_instead_of_claiming_idle() {
        let f = Fixture::new();
        f.fd(7, 1, "/dev/null");
        for limits in [
            ScanLimits {
                processes: 0,
                ..ScanLimits::default()
            },
            ScanLimits {
                descriptors: 0,
                ..ScanLimits::default()
            },
            ScanLimits {
                users: 0,
                ..ScanLimits::default()
            },
        ] {
            let o = observe_at(&f.0, &[Path::new("/dev/null")], limits).unwrap();
            assert!(o.partial());
            assert!(o.scan_limit_reached);
        }
    }
    #[test]
    fn missing_regular_duplicate_and_empty_devices_are_rejected() {
        let f = Fixture::new();
        let file = f.0.join("regular");
        fs::write(&file, "x").unwrap();
        for paths in [
            vec![],
            vec![file.as_path()],
            vec![Path::new("/remoteops-no-device")],
            vec![Path::new("/dev/null"), Path::new("/dev/null")],
        ] {
            assert!(observe_at(&f.0, &paths, ScanLimits::default()).is_err());
        }
        assert!(observe_at(
            &f.0.join("missing-proc"),
            &[Path::new("/dev/null")],
            ScanLimits::default()
        )
        .is_err());
    }
    #[test]
    fn empty_visible_namespace_and_json_escaping_never_grant_admission() {
        let f = Fixture::new();
        fs::create_dir(f.0.join("self")).unwrap();
        let mut o = f.observe();
        assert!(o.users.is_empty());
        assert!(!o.partial());
        o.devices[0].path = "quote\"\n".to_owned();
        let json = o.to_json();
        assert!(json.contains("quote\\\"\\n"));
        assert!(json.contains("\"demonstrates_device_idle\":false"));
        assert!(json.contains("\"qualifies_exclusivity\":false"));
    }
    #[test]
    fn detailed_gaps_preserve_partial_and_verify_process_context() {
        let f = Fixture::new();
        f.fd(7, 1, "/remoteops-missing-fd-1");
        f.fd(7, 2, "/remoteops-missing-fd-2");
        let pid = f.0.join("7");
        let stat = format!("7 (name ) with spaces) S {} 123\n", vec!["0"; 18].join(" "));
        fs::write(pid.join("stat"), stat).unwrap();
        fs::write(pid.join("cgroup"), "0::/system.slice/test.service\n").unwrap();
        let d = observe_detailed_at(&f.0, &[Path::new("/dev/null")], ScanLimits::default(), true)
            .unwrap();
        assert!(d.observation.partial());
        assert_eq!(d.observation.unreadable_entries, 2);
        assert_eq!(d.gaps.len(), 1);
        assert_eq!(d.gaps[0].count, 2);
        assert!(d.gaps[0].process_identity_verified);
        assert_eq!(
            d.gaps[0].cgroup_v2.as_deref(),
            Some("/system.slice/test.service")
        );
        let json = d.to_json();
        assert!(json.contains("remoteops.device-users/v2"));
        assert!(json.contains("\"status\":\"partial\""));
        assert!(json.contains("\"qualifies_exclusivity\":false"));
        fs::write(pid.join("cgroup"), "x".repeat(4097)).unwrap();
        let d = observe_detailed_at(&f.0, &[Path::new("/dev/null")], ScanLimits::default(), true)
            .unwrap();
        assert!(!d.gaps[0].process_identity_verified);
        assert!(d.gaps[0].cgroup_v2.is_none());
    }

    #[test]
    fn missing_changed_identity_and_truncated_details_remain_unknown() {
        let f = Fixture::new();
        f.fd(7, 1, "/remoteops-missing-fd");
        let mut d =
            observe_detailed_at(&f.0, &[Path::new("/dev/null")], ScanLimits::default(), true)
                .unwrap();
        assert!(!d.gaps[0].process_identity_verified);
        let before = ("123".to_owned(), "/system.slice/a.service".to_owned());
        d.gap(
            Some(7),
            "fd_metadata",
            Some(&before),
            Some(("124".to_owned(), before.1.clone())),
        );
        assert!(!d.gaps.last().unwrap().process_identity_verified);
        for pid in 8..4110 {
            d.gap(Some(pid), "fd_metadata", None, None);
        }
        assert_eq!(d.gaps.len(), 4096);
        assert!(d.gap_details_truncated);
        let previous = d.gaps[0].count;
        d.gap(Some(7), "fd_metadata", None, None);
        assert_eq!(d.gaps[0].count, previous + 1);
        assert_eq!(d.gaps.len(), 4096);
        assert!(d.observation.partial());
        assert!(d.to_json().contains("\"gap_details_truncated\":true"));
        let legacy = observe_detailed_at(
            &f.0,
            &[Path::new("/dev/null")],
            ScanLimits::default(),
            false,
        )
        .unwrap();
        assert!(legacy.gaps.is_empty());
        assert_eq!(legacy.observation.unreadable_entries, 1);
    }
}
