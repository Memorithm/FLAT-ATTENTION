#!/usr/bin/env bash
set -euo pipefail
umask 022
root=$1
test "$(id -un)" = memci
test "$(hostname)" = debian
test "$(uname -m)" = x86_64
test -r /dev/dri/renderD128 && test -w /dev/dri/renderD128
for forbidden in sudo wheel docker lxd; do
  if id -nG | tr ' ' '\n' | grep -qx "$forbidden"; then exit 3; fi
done
export PATH="$root/toolchain/bin:/usr/bin:/bin"
export CARGO_HOME="$root/cargo" CARGO_TARGET_DIR="$root/target" CARGO_BUILD_JOBS=4
export FLAT_SOURCE_REVISION=b020d31711d75807eb0f8b13a6a967a8522c5d1c
export FLAT_REQUIRE_WGPU=1 WGPU_BACKEND=vulkan
export XDG_RUNTIME_DIR="$root/xdg"
mkdir -m 700 "$XDG_RUNTIME_DIR"
rustc --version --verbose > "$root/compiler.txt"
grep -qx 'release: 1.89.0' "$root/compiler.txt"
id > "$root/execution-account.txt"
cat /sys/module/nvidia/version > "$root/driver.txt"
git -c credential.helper= clone --quiet https://github.com/Memorithm/FLAT-ATTENTION.git "$root/source"
cd "$root/source"
git checkout --quiet "$FLAT_SOURCE_REVISION"
test "$(git rev-parse HEAD)" = "$FLAT_SOURCE_REVISION"
test -z "$(git status --porcelain)"
git rev-parse HEAD > "$root/source-revision.txt"
sha256sum Cargo.lock > "$root/lockfile-before.txt"
cargo test --locked --release --features wgpu --test pvp_canonical_e2e --no-run > "$root/build.log" 2>&1
sha256sum Cargo.lock > "$root/lockfile-after.txt"
cmp "$root/lockfile-before.txt" "$root/lockfile-after.txt"
mapfile -t binaries < <(find "$root/target/release/deps" -maxdepth 1 -type f -name 'pvp_canonical_e2e-*' -executable)
test "${#binaries[@]}" -eq 1
binary=${binaries[0]}
sha256sum "$binary" > "$root/binary-before.txt"
failures=0
for run in {1..10}; do
  dir="$root/run-$run"; mkdir "$dir"
  date -u --iso-8601=ns > "$dir/start.txt"
  (
    exec 9<>/dev/nvidia0
    flock -n -x 9 || { printf 'lease=busy\n' > "$dir/lease.txt"; exit 75; }
    if flock -n /dev/nvidia0 -c true 9>&-; then exit 76; fi
    printf 'lease=cooperative_only; admission=none\n' > "$dir/lease.txt"
    timeout --signal=TERM --kill-after=10s 900s "$binary" --exact canonical_end_to_end_diagnostic --nocapture --test-threads=1 > "$dir/timing.log" 2>&1
  ) && result=0 || result=$?
  printf '%s\n' "$result" > "$dir/exit.txt"
  date -u --iso-8601=ns > "$dir/end.txt"
  if test "$result" -ne 0; then failures=$((failures+1)); fi
  if ! grep -Fxq 'PVP_E2E_COMPLETE,samples=1440,rejected_geometries=0,failed_comparisons=0,performance_admission=none' "$dir/timing.log"; then failures=$((failures+1)); fi
  if ! grep -Fxq 'PVP_E2E_ADAPTER,name="NVIDIA GeForce RTX 4060",backend=Vulkan,driver="595.45.04",type=DiscreteGpu' "$dir/timing.log"; then failures=$((failures+1)); fi
  test "$(grep -c '^PVP_E2E_COMPLETE,' "$dir/timing.log" || true)" = 1 || failures=$((failures+1))
  printf 'run=%s exit=%s completed_utc=%s\n' "$run" "$result" "$(cat "$dir/end.txt")"
done
sha256sum "$binary" > "$root/binary-after.txt"
cmp "$root/binary-before.txt" "$root/binary-after.txt"
test -z "$(git status --porcelain)"
printf 'processes=10 failure_checks=%s accepted_performance_rows=0 services_changed=false\n' "$failures" > "$root/verdict.txt"
test "$failures" -eq 0
