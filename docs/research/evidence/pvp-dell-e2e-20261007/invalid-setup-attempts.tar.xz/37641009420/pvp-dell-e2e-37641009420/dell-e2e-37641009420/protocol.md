# Native Dell canonical end-to-end timing: frozen diagnostic protocol

Freeze this control commit and FLAT b020d31711d75807eb0f8b13a6a967a8522c5d1c before execution.
Target: Dell T430, native x86_64, RTX 4060, Vulkan, installed driver 595.45.04, Rust 1.89.0 release.
Only the installed GPU driver is vendor specific. No CUDA, NVML, nvidia-smi or SDK bridge.

Use the existing canonical_end_to_end_diagnostic test unchanged.
Fixed ordered shapes: (4096,128), (16384,2048), (65536,512), (262144,128), (16384,129), (65536,129).
Banks boundary/sparse4/dense32; arms vec4/packed7; modes prepared/fresh_resources.
Five warmups and twenty alternating paired measured repetitions per endpoint and arm.
Ten numbered fresh processes with separately acquired/released cooperative locks; no replacement or retries.
Expected per process: 1440 measured samples, 360 warmups, 7200 complete oracle comparisons.
Full cohort: 14400 measured samples, 3600 warmups, 72000 complete comparisons.
Require successful exit, exact source/native adapter, unique complete keys, every word/padding/guard exact,
unchanged lock and binary hashes. Retain failed attempts and rejected geometries.

Endpoint: same canonical gate-major u64 host input to host output, including scalar conversion,
mode preparation, upload fencing, encode/submit/wait, one explicit MAP_READ, reverse conversion.
Prepared resources are outside the timer. Fresh resources use an already-created warm device/context;
device startup/destruction are excluded. A second independent readback and all oracle checks are outside timing.
Total contiguous wall latency is authoritative; component subtotals are diagnostic.

Report twenty paired vec4-wall/packed7-wall ratios per process and endpoint, their median,
then all ten process medians. Report their median/range and p50/p95 raw latencies plus all regressions.
The 36 endpoints and 1.05 descriptive threshold are fixed before execution.
Do not pool repetitions as independent sessions. No confirmatory p-value or performance admission:
independent occupancy/sampling review and SML-owned bank/destination qualification remain separate.

Root compiles only trusted RemoteOps std-only observer source in a root-owned directory.
Five preflight scans, one-second loop scans during build/execution, five final scans are retained with UTC/exit codes.
Positive device users are observations of open descriptors, not proof of compute activity.
Empty or partial scans do not establish GPU idle/exclusivity; no kernel lifecycle trace or hostile-process fencing.
All samples remain diagnostic and admission=none, including observed foreign users/gaps.
No service pause, persistent group change or historical binary modification.
FLAT code runs only as memci in a scoped render-group systemd unit, 12G/400% CPU/45min limits.
This supervision is not a hostile-code sandbox. Each process timeout is 900s; workflow limit 50min.
Dell and Thor are separate cohorts. No default route, register allocation, bandwidth, model-quality
or SML throughput claim. Final SML remains self sufficient; FLAT/SciRust/NNIS remain optional partners.
