# Dell prepared-plan correctness — frozen before execution

Date: 2026-10-07. Functional study only; no latency or occupancy qualification.

Readiness run 37635323320 established native x86_64 host debian, driver
595.45.04, an existing memci account without privileged groups, and absent
render-device access/Rust in that account's login environment.

Pinned source: FLAT-ATTENTION b020d31711d75807eb0f8b13a6a967a8522c5d1c.
Use existing Rust 1.89.0 host toolchain copied into a unique task directory.
Do not download/execute an installer as root; missing toolchain fails closed.
Locked release-profile build of test pvp_wgpu_prepared, then exactly three
numbered fresh processes, three coefficient rounds. Fixed corpus: 16 shapes,
boundary/sparse4/dense32 banks; vec4/fused2/tile8/packed1/packed7. Each process
expects 720 cases and 6480 complete paired source/forward/inverse comparisons.
Success requires exit 0, expected complete marker, no failed comparisons, clean
source, unchanged lockfile/binary, actual non-software Vulkan adapter.
All words, padding and four outside-binding sentinels remain checked.

RemoteOps starts one transient service as memci, with the existing render-device
group scoped to that process only. No account membership/permission mutation.
NoNewPrivileges, read-only system/home, private temporary namespace, writable
task directory, 12 GiB memory, four CPU equivalents and 40-minute lifetime
limit apply. This is process hardening, not a hostile-code sandbox. GPU code
and cargo build run unprivileged; root stages only trusted files and the unit.

Each process acquires/releases its cooperative device lock separately, testing
contention. Busy/failing attempts retain their number and evidence; no retries.
The lock does not establish idle/exclusive admission. Services are not stopped,
unknown/shared activity is not upgraded, accepted performance rows remain zero.
No CUDA/NVML/vendor management command is used.

Source/harness/protocol, toolchain, driver, binary, raw comparisons, timestamps
and exit receipts are retained on the host and as 14-day workflow artifacts.
Dell results remain separate from Thor (whose prior prepared test used a debug
profile). This gate authorizes neither speed, model quality, default routing nor
SML internalization. SML-owned banks and destination requalification remain due.
