import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1])
manifest=json.loads((root/"frozen-inputs.json").read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert json.loads((root/"restoration-7-reinspection-exit.json").read_text())["returncode"] == 0
for block in range(8,11):
    scope="remoteops-pvp-e2e-"+root.name.rsplit(".",1)[-1]+"-b"+str(block)
    with (root/f"dispatch-{block}.log").open("x") as log:
        result=subprocess.run(["systemd-run","--unit="+scope,"--property=RuntimeMaxSec=25min",
            "--wait","--pipe","/bin/bash",str(root/"control.sh"),str(root),str(block)],
            stdout=log,stderr=subprocess.STDOUT)
    (root/f"dispatch-{block}-exit.json").write_text(json.dumps({"returncode":result.returncode})+"\n")
    # A failed/ambiguous restoration stops the campaign. No subsequent lease
    # starts before this separate read-only receipt succeeds.
    receipt=subprocess.run(["python3",str(root/"inspect-restoration.py"),str(root),str(block)],
        capture_output=True,text=True)
    (root/f"restoration-{block}.stdout").write_text(receipt.stdout)
    (root/f"restoration-{block}.stderr").write_text(receipt.stderr)
    assert receipt.returncode==0,receipt.stderr
    restored=json.loads(receipt.stdout)
    (root/f"restoration-{block}.json").write_text(receipt.stdout)
    log=root/f"block-{block}/run-1/timing.log"
    completed=[x for x in log.read_text().splitlines() if x.startswith("PVP_E2E_COMPLETE,")] if log.exists() else []
    control=(root/f"block-{block}/control.log").read_text()
    print(json.dumps({"block":block,"dispatch_exit":result.returncode,"restoration":"verified",
        "complete":completed,"incomplete_observation_markers":control.count("observation_incomplete")}),flush=True)
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}
(root/"evidence-files.json").write_text(json.dumps(files,indent=2)+"\n")
print(json.dumps({"remaining_planned_leases_finished":True,"planned_leases":10,"resumed_after_read_only_reconciliation":True,"performance_admission":"none"}),flush=True)
