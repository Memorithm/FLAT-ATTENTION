import hashlib,json,pathlib,re,subprocess,sys
root=pathlib.Path(sys.argv[1]);block=sys.argv[2]
scope="remoteops-pvp-e2e-"+root.name.rsplit(".",1)[-1]+"-b"+block
lease=root/("block-"+block)
services={}
for unit in ["memorithm-clm.service","memorithm-clm-encoder.service","memorithm-viggle-lan.service","rustdesk.service"]:
    out=subprocess.check_output(["systemctl","show",unit,"--property=ActiveState,Restart,RefuseManualStart"],text=True)
    record=dict(x.split("=",1) for x in out.splitlines() if "=" in x)
    assert record["ActiveState"]=="active" and record["RefuseManualStart"]=="no",unit
    assert record["Restart"]==("no" if unit=="rustdesk.service" else "on-failure"),unit
    assert not pathlib.Path(f"/run/systemd/system/{unit}.d/90-{scope}.conf").exists(),unit
    services[unit]=record
assert not pathlib.Path(f"/sys/kernel/tracing/instances/{scope}").exists()
timer=subprocess.run(["systemctl","is-active",scope+"-restore.timer"],capture_output=True,text=True)
assert timer.returncode!=0 and timer.stdout.strip() in ["inactive","unknown"]
assert subprocess.run(["flock","-n","/dev/nvidia0","-c","true"]).returncode==0
control=(lease/"control.log").read_text()
match=re.search(r"reservation_released_exit=(\d+)\n$",control);assert match,"missing cleanup receipt"
binary=pathlib.Path((root/"binary-path.txt").read_text().strip())
bh=hashlib.sha256(binary.read_bytes()).hexdigest()
assert bh==(root/"binary-sha256.txt").read_text().strip()
historical=pathlib.Path("/var/tmp/remoteops-pvp-r8-build.c15g0q5t/source/target/release/examples/pvp3d_three_candidate_bench")
hh=hashlib.sha256(historical.read_bytes()).hexdigest()
assert hh=="7aef67026ad088504478885cf9f2b7c864218f6fb3b0792bd8609fd907d3f414"
timing=pathlib.Path("/var/tmp/remoteops-pvp-timing.nGx9ZQGx/pvp_prepared_timing")
th=hashlib.sha256(timing.read_bytes()).hexdigest()
assert th=="953dab3555d3ea2326229e0c265c55dddaee05eae09e9e8195e66057fb3baa11"
print(json.dumps({"schema":"flat.pvp-e2e-restoration/v1",
    "inspected_at_utc":subprocess.check_output(["date","-u","--iso-8601=ns"],text=True).strip(),
    "block":int(block),"services":services,"guards_removed":True,"trace_instance_removed":True,
    "restore_timer_inactive":True,"cooperative_lock_available":True,"controller_exit":int(match.group(1)),
    "binary_sha256":bh,"historical_benchmark_sha256":hh,"historical_timing_sha256":th,
    "performance_admission":"none"},indent=2))
